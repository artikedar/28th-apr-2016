package org.capgemini.domain;

import org.springframework.beans.factory.annotation.Autowired;

public class Address {
	
	private int addrId;
	private int doorNo;
	private int stNo;
	private String city;
	private String state;
	
	@Autowired
	private Address(){}
	
	public Address(int addrId, int doorNo, int stNo, String city, String state) {
		super();
		this.addrId = addrId;
		this.doorNo = doorNo;
		this.stNo = stNo;
		this.city = city;
		this.state = state;
	}
	public int getAddrId() {
		return addrId;
	}
	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public int getStNo() {
		return stNo;
	}
	public void setStNo(int stNo) {
		this.stNo = stNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [addrId=" + addrId + ", doorNo=" + doorNo + ", stNo=" + stNo + ", city=" + city + ", state="
				+ state + "]";
	}
	
}
