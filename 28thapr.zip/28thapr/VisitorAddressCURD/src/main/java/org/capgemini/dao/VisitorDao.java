package org.capgemini.dao;

import java.util.List;

import javax.sql.DataSource;

import org.capgemini.domain.Visitor;

public interface VisitorDao {

	public void setDataSource(DataSource dataSource);
	
	public void createVisitor(Visitor visitor);
	
	public List<Visitor> getAllVisitor();
}
