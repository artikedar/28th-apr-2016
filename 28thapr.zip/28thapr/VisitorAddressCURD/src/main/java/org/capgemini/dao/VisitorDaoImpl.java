package org.capgemini.dao;

import java.util.List;

import javax.sql.DataSource;

import org.capgemini.domain.Visitor;
import org.capgemini.domain.VisitorRow;
import org.springframework.jdbc.core.JdbcTemplate;

public class VisitorDaoImpl implements VisitorDao{

	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
	}

	public void createVisitor(Visitor visitor) {
		

		String sql="insert into visitor values(?,?,?)";
		jdbcTemplate.update(sql, new Object[]{visitor.getVisitId(),visitor.getName(),visitor.getVisitAddrDetails().getAddrId()});
		
		String sql1="insert into address values(?,?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[]{visitor.getVisitAddrDetails().getAddrId(),visitor.getVisitAddrDetails().getDoorNo(),visitor.getVisitAddrDetails().getStNo(),visitor.getVisitAddrDetails().getCity(),visitor.getVisitAddrDetails().getState()});

		

		
		
		
	}

	public List<Visitor> getAllVisitor() {
		
		Visitor visitor=new Visitor();
		String sql="select * from address,visitor where visitor.addId=address.addrId";
		
		List<Visitor> visitors=jdbcTemplate.query(sql, new VisitorRow());
		
		return visitors;
	}

}
