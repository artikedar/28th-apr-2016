package org.capgemini.domain;

import org.springframework.beans.factory.annotation.Autowired;

public class Visitor {



	private int visitId;
	private String name;
	
	Address visitAddrDetails;
	
	@Autowired
	public Visitor(int visitId, String name, Address visitAddrDetails) {
		super();
		this.visitId = visitId;
		this.name = name;
		this.visitAddrDetails = visitAddrDetails;
	}

	public Visitor(){}
	
	public Visitor(int visitId, String name) {
		super();
		this.visitId = visitId;
		this.name = name;
	}
	

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public Address getVisitAddrDetails() {
		return visitAddrDetails;
	}

	public void setVisitAddrDetails(Address visitAddrDetails) {
		this.visitAddrDetails = visitAddrDetails;
	}

	@Override
	public String toString() {
		return "Visitor [visitId=" + visitId + ", name=" + name + ", visitAddrDetails=" + visitAddrDetails + "]";
	}

	
}
