package org.capgemini.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class VisitorRow implements RowMapper<Visitor>{

	public Visitor mapRow(ResultSet rs, int count) throws SQLException {
		
		Visitor visitor=new Visitor();
		int addrId=0;
		int doorNo=0;
		int stNo=0;
		String city=null;
		String state=null;
		
		VisitorRow ad=new VisitorRow();
		
		Address addr=new Address(addrId,doorNo,stNo,city,state);
		addr.setAddrId(rs.getInt(1));
		addr.setDoorNo(rs.getInt(2));
		addr.setStNo(rs.getInt(3));
		addr.setCity(rs.getString(4));
		addr.setState(rs.getString(5));
			
		visitor.setVisitAddrDetails(addr);
		visitor.setVisitId(rs.getInt(6));
		visitor.setName(rs.getString(7));
		
		//System.out.println(visitor);
		
		return visitor;
	}

}
