package org.capgemini.domain;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {
	
	@Bean
	@Scope(value="prototype")
	public Address getAddress(){
		return new Address(1, 404, 12, "Pune", "Maharashtra");
	}
	
	@Bean
	public Visitor getVisitor(){
		return new Visitor(101, "Ram",getAddress());
		
	}
	
	

}
