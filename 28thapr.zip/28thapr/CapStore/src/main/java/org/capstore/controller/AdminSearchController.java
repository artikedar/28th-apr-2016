package org.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller

public class AdminSearchController {

	@RequestMapping("/customer")
	public ModelAndView searchCustomer(){
		String message="U are searching customer";
		return new ModelAndView("cutomerSearch","msg",message);
	}
	
	
	@RequestMapping("/merchant")
	public ModelAndView searchMerchant(){
		String message="U are searching merchant";
		return new ModelAndView("merchantSearch","msg",message);
	}
	
	@RequestMapping("/inventory")
	public ModelAndView searchInventory(){
		String message="U are searching inventory";
		return new ModelAndView("inventorySearch","msg",message);
	}
}
