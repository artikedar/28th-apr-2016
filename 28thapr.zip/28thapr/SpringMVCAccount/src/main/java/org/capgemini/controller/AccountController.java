package org.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountController {

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String msg="Hello World!";
		return new ModelAndView("helloPage","message",msg);
	}
}
